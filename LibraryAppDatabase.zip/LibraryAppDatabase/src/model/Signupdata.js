const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/library');

const Schema = mongoose.Schema;

const SignupSchema = new Schema({

    fname: String,
    lname: String,
    number: String,
    email: String,
    password: String,
    cpassword: String

});



var Signupdata = mongoose.model('signupdata',SignupSchema);

module.exports = Signupdata;