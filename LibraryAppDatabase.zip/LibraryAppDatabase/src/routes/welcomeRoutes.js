const express = require('express');
const welcomeRouter = express.Router();
function router(nav,navwelcome){


    
    welcomeRouter.get('/',function(req,res){
        res.render("welcome",{
            nav,
            navwelcome,
            title: 'WELCOME'
        });
    });
    

return welcomeRouter;

}

module.exports = router;  