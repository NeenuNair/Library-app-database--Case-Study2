// const express = require('express');
// const adminRouter = express.Router();
// const Bookdata = require('../model/Bookdata');

// function router(nav,navBooks){
//     adminRouter.get('/',function(req,res){
//         res.render('addBook',{
//             nav,
//             navBooks,
//             title:'ADD BOOKS'
//         })
//     })


// adminRouter.post('/add',function(req,res){

//     var item ={
//       title:req.body.title,
//       author:req.body.author,
//       genre:req.body.genre,
//       image:req.body.image
//     }

//     var book = Bookdata(item);
//     book.save();
//     res.redirect('/ebooks');
    
// });

// return adminRouter;


// }

// module.exports = router;
const express = require('express');
const adminRouter = express.Router();
const Bookdata = require('../model/Bookdata');

function router(nav,navBooks){
        adminRouter.get('/',function(req,res){
            res.render('addBook',{
                nav,
                navBooks,
                title:'ADD BOOKS'
            })
        })
adminRouter.post('/add',function(req,res){

    var item ={
      title:req.body.title,
      author:req.body.author,
      genre:req.body.genre,
      image:req.body.image
    }

    var book = Bookdata(item);
    book.save();
    res.redirect('/ebooks');
    
});

adminRouter.get('/updatebook/:id',(req,res)=>

{
    const id = req.params.id;
    Bookdata.findOne({_id:id})
    .then(function(ebookSingle){
        res.render('updatebook', {
            nav,
            title: "UPDATE BOOK",
            ebookSingle
        });
    })
});

adminRouter.post('/update/:id',(req,res)=>
{
    const id = req.params.id;
    if(req.body.image=="")
    {
        Bookdata.updateOne({_id:id},{$set:{title:req.body.title, author:req.body.author, genre:req.body.genre, image:req.body.image}})
        .then((ebooks)=>{
            res.redirect('/ebooks');
        })
        }
        else{
            Bookdata.updateOne({_id:id},{$set:{title:req.body.title, author:req.body.author, genre:req.body.genre, image:req.body.image}})
            .then((ebooks)=>{
                res.redirect('/ebooks');
            })
        }
    })

adminRouter.get('/deletebook/:id',(req,res)=>{
    const id = req.params.id;
    Bookdata.deleteOne({_id:id})
    .then((ebooks)=>
    {

    res.redirect('/ebooks');
    })
})


return adminRouter;


}

module.exports = router;