const express = require('express');
const authorRouter = express.Router();
const Authordata = require('../model/Authordata');
function router(nav, navAuthor){



    authorRouter.get('/',function(req,res){
        Authordata.find()
        .then(function(author){
            res.render("author",{
                nav,
                navAuthor,
                title: 'AUTHORS',
                author
            
            });
        })
       
    });
    
    authorRouter.get('/:id',function(req,res){
       const id = req.params.id
       Authordata.findOne({_id: id})
       .then(function(authorSingle){
         res.render('authorSingle',{
             nav,
             title: 'AUTHOR',   
             authorSingle
             
         });
       })
    
     });


return authorRouter;

}

module.exports = router;