const express = require('express');
const contactRouter = express.Router();
function router(nav,navSign){


    
    contactRouter.get('/',function(req,res){
        res.render("contact",{
            nav,
            navSign,
            title: 'CONTACT US'
        });
    });
    

return contactRouter;

}

module.exports = router;  