const express = require('express');
const mbooksRouter = express.Router();
function router(nav, navBooks){

    var mbooks = [

        {
            title:'RANDAMOOZHAM',
            author:'AUTHOR: M. T. Vasudevan Nair',
            genre:'GENRE:  FICTION',
            img:'1.jpg'
        },
    
        {
            title:'AADUJEEVITHAM',
            author:'AUTHOR: Benyamin',
            genre:'GENRE: FICTION',
            img:'aadu.jpg'
        },
        {
            title:'ENTE KATHA',
            author:'AUTHOR: Kamala Surayya',
            genre:'GENRE: HORROR',
            img:'ente kadha.jpg'
        },
    
        {
            title:'KHASAKKINTAE ITHIHASAM',
            author:'AUTHOR: O. V. Vijayan',
            genre:'GENRE: FANTASY',
            img:'khasakh1.jpg'
        }
    ]
 
    
    
    mbooksRouter.get('/',function(req,res){
        res.render("mbooks",{
            nav,
            navBooks,
            title: 'WELCOME TO DIGITAL LIBRARY',
            mbooks, 
        });
    });
    
    mbooksRouter.get('/:id', function(req,res){
       const id = req.params.id
        res.render('mbookSingle',{
            nav,
            navBooks,
            title: 'WELCOME TO NATIONAL PUBLIC LIBRARY',   
            mbookSingle:mbooks[id]
        });
    });

return mbooksRouter;

}

module.exports = router;