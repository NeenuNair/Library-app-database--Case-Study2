const express = require('express');
const updateauthorRouter = express.Router();
function router(nav){


    
    updateauthorRouter.get('/',function(req,res){
        res.render("updateauthor",{
            nav,
            title: 'UPDATE AUTHORS'
        });
    });
    

return updateauthorRouter;

}

module.exports = router;  