const express = require('express');
const adminauthorRouter = express.Router();
const Authordata = require('../model/Authordata');

function router(nav){
    adminauthorRouter.get('/',function(req,res){
        res.render('addAuthor',{
            nav,
            title:'ADD AUTHOR'
        })
    })


adminauthorRouter.post('/add',function(req,res){

    var item ={
      author:req.body.author,
      dob:req.body.dob,
      image:req.body.image
    }

    var authorSingle = Authordata(item);
    authorSingle.save();
    res.redirect('/author');
    
});

adminauthorRouter.get('/updateauthor/:id',(req,res)=>

{
    const id = req.params.id;
    Authordata.findOne({_id:id})
    .then(function(authorSingle){
        res.render('updateauthor', {
            nav,
            title: "UPDATE AUTHOR",
            authorSingle
        });
    })
});

adminauthorRouter.post('/update/:id',(req,res)=>
{
    const id = req.params.id;
    if(req.body.image=="")
    {
        Authordata.updateOne({_id:id},{$set:{author:req.body.author, dob:req.body.dob, image:req.body.image}})
        .then((author)=>{
            res.redirect('/author');
        })
        }
        else{
            Authordata.updateOne({_id:id},{$set:{ author:req.body.author, dob:req.body.dob, image:req.body.image}})
            .then((author)=>{
                res.redirect('/author');
            })
        }
    })

adminauthorRouter.get('/deleteauthor/:id',(req,res)=>{
    const id = req.params.id;
    Authordata.deleteOne({_id:id})
    .then((author)=>
    {

    res.redirect('/author');
    })
})



return adminauthorRouter;


}

module.exports = router;