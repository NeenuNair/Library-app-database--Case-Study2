const express = require('express');
const loginRouter = express.Router();
const Signupdata = require('../model/Signupdata');
const app = new express();
var loginStatus;

function router(nav){

    loginRouter.get('/',function(req,res){

        if(loginStatus == "Incorrect Email ID & Password"){
            res.render("login",{
            nav,
            status:loginStatus
            });
        }
        
        else{

            res.render("login",{
                nav,
                status: "Enter Email ID and Password"
    
                })
        }
    })
    
    loginRouter.post('/addlogin',function(req,res){
        
    let email=req.body.email;
    let password=req.body.password;

    Signupdata.findOne({email:email,password:password})
    .then(function(details){

        if(details===null)
        {
            loginStatus="Invalid Email ID & Password";
            res.redirect('/login');
        }
        else{
            loginStatus="Login Successfull";
            res.redirect('/ebooks');
        }
    })
})

    loginRouter.get("/",function (req,res){
        res.render("login", {
            // title:"LOG IN",
        });
    });


return loginRouter;

}

module.exports = router;  