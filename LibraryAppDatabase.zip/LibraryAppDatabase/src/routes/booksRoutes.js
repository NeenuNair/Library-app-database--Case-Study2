const express = require('express');
const booksRouter = express.Router();
function router(nav,navSign){


    
    booksRouter.get('/',function(req,res){
        res.render("books",{
            nav,
            navSign,
            
            title: 'ABOUT US'
        });
    });
    

return booksRouter;

}

module.exports = router;  