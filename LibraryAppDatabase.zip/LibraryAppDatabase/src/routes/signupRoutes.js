// const express = require('express');
// const signupRouter = express.Router();
// function router(nav){


    
//     signupRouter.get('/',function(req,res){
//         res.render("signup",{
//             nav,
//             title: 'WELCOME TO DIGITAL LIBRARY'
//         });
//     });
    

// return signupRouter;

// }

// module.exports = router;  

const express = require('express');
const signupRouter = express.Router();
const Signupdata = require('../model/Signupdata');
function router(nav){


    
    signupRouter.get('/',function(req,res){
        res.render("signup",{
            nav,
            title: 'SIGN UP'
        });
    });
    

    signupRouter.post('/adddetails',function(req,res){

        var item ={
          fname:req.body.fname,
          lname:req.body.lname,
          number:req.body.number,
          email:req.body.email,
          password:req.body.password,
          cpassword:req.body.cpassword
        }
    
        var signupdetails = Signupdata(item);
        signupdetails.save();
        res.redirect('/login');
        
    });
    


return signupRouter;

}

module.exports = router;  