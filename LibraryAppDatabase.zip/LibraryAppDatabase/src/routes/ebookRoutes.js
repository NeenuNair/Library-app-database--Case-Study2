const express = require('express');
const ebooksRouter = express.Router();
const Bookdata = require('../model/Bookdata');

function router(nav,navBooks){

        // var ebooks = [
    
        //     {
        //         title:'DRACULA',
        //         author:'AUTHOR: A BRAM STOKER',
        //         genre:'GENRE: HORROR',
        //         img:'dracula.jpg'
        //     },
    
        //     {
        //         title:'THE COUNT OF MONTE CRISTO',
        //         author:'AUTHOR: ALEXANDRE DUMAS',
        //         genre:'GENRE: FICTION',
        //         img:'monte cristo.jpg'
        //     },
        
        //     {
        //         title:'THE TALE OF TWO CITIES',
        //         author:'AUTHOR: CHARLES DICKENS',
        //         genre:'GENRE: FICTION',
        //         img:'tales of two cities.jpg'
        //     },
        //     {
        //         title:'THE ADVENTURES OF SHERLOCK HOMES',
        //         author:'AUTHOR: ARTHUR CONA DOYLE',
        //         genre:'GENRE: Thriller',
        //         img:'sherlak.jpg'
        //     },

            
        // ]
    
    
    ebooksRouter.get('/',function(req,res){
        Bookdata.find()
        .then(function(ebooks){
            res.render("ebooks",{
                nav,
                navBooks,
                title: 'WELCOME TO DIGITAL LIBRARY',
                ebooks
        })
    
        });
    });
    
    ebooksRouter.get('/:id', function(req,res){
       const id = req.params.id
       Bookdata.findOne({_id:id})
       .then(function(ebookSingle){
        res.render('ebookSingle',{
            nav,
            navBooks,
            title: 'WELCOME TO DIGITAL LIBRARY',   
            ebookSingle
        });
       })
        
    });

return ebooksRouter;

}

module.exports = router;