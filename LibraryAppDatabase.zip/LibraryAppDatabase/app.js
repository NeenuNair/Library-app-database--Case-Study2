const express = require('express');
const app = express();
const nav =
[
    {
        link:'/books',name:'ABOUT US'
    }, 
    
    {
        link:'/contact',name:'CONTACT US'
    }
    
];
const navSign =
[
    {
        Link:'/login',Name:'LOG IN'
    }, 
    
    {
        Link:'/signup',Name:'SIGN UP'
    }
];
const navBooks =
[
    {
        lin:'/ebooks',book:'BOOKS'
    }, 

    {
        lin:'/admin',book:'ADD BOOKS'
    },
    {
        lin:'/author',book:'AUTHORS'
    }

];

const navAuthor =
[
    
    {
        LINK:'/adminAuthor',NAME:'ADD AUTHOR' 
    }
];



const booksRouter = require('./src/routes/booksRoutes')(nav,navSign)
const ebooksRouter = require('./src/routes/ebookRoutes')(nav,navBooks)
const mbookRouter = require('./src/routes/mbookRoutes')(nav,navBooks)
const contactRouter = require('./src/routes/contactRoutes')(nav,navSign)
const authorRouter = require('./src/routes/authorRoutes')(nav,navAuthor)
// const loginRouter = require('./src/routes/loginRoutes')(nav)
const loginRouter = require('./src/routes/loginRoutes')(nav)
const signupRouter = require('./src/routes/signupRoutes')(nav)
const adminRouter = require('./src/routes/adminRoutes')(nav,navBooks)
const adminAuthorRouter = require('./src/routes/adminAuthorRoutes')(nav,navAuthor)
const updatebookRouter = require('./src/routes/updatebookRoutes')(nav)
const updateauthorRouter = require('./src/routes/updateauthorRoutes')(nav)


app.use(express.urlencoded({extended:true}));
app.use(express.static('./public'));
app.set('view engine','ejs');
app.set('views','./src/views');

app.use('/books',booksRouter);
app.use('/ebooks',ebooksRouter);
app.use('/mbooks',mbookRouter);
app.use('/contact',contactRouter);
app.use('/author',authorRouter);
app.use('/login',loginRouter);
app.use('/signup',signupRouter);
app.use('/admin',adminRouter);
app.use('/adminAuthor',adminAuthorRouter);
app.use('/updatebook',updatebookRouter);
app.use('/updateauthor',updateauthorRouter);



app.get('/',function(req,res){
    res.render("index",
    {  
        nav,
        navSign,
        title: 'WELCOME TO DIGITAL LIBRARY'
    });
});


app.listen(5000);